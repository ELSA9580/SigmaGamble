package com.example.meinmod;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;

/** Zeichnet die Boxen (Haupt-Box und Session-Popup) ins HUD. */
public final class Hud {
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GRAY = 0xFFBBBBBB;
    public static final int GREEN = 0xFF55FF55;
    public static final int RED = 0xFFFF5555;
    public static final int GOLD = 0xFFFFD21E;

    private static final int PAD = 5;
    private static final int LH = 11;

    public record Line(String text, int color) {}

    private Hud() {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Font font = mc.font;

        List<Line> main = mainLines();
        if (!main.isEmpty()) drawPanel(g, font, main, Config.x, Config.y);
        if (Config.popup) drawPanel(g, font, popupLines(), Config.popupX, Config.popupY);
    }

    /** Zeilen der Haupt-Box (Profit- und Taxes-Modul). */
    public static List<Line> mainLines() {
        List<Line> lines = new ArrayList<>();
        synchronized (Stats.class) {
            if (Config.profit) {
                lines.add(profitLine("Profit (Session): ", Stats.profit(Stats.session)));
                lines.add(profitLine("Profit (Gesamt): ", Stats.profit(Stats.total)));
            }
            if (Config.taxes) {
                lines.add(new Line("Taxes (Session): " + Stats.fmt(Stats.session[Stats.TAX]), GOLD));
                lines.add(new Line("Taxes (Gesamt): " + Stats.fmt(Stats.total[Stats.TAX]), GOLD));
            }
        }
        return lines;
    }

    /** Zeilen des Session-Popups. */
    public static List<Line> popupLines() {
        double v;
        synchronized (Stats.class) {
            v = Stats.profit(Stats.session);
        }
        String sign = v > 0 ? "+" : "";
        int color = v > 0 ? GREEN : (v < 0 ? RED : WHITE);
        List<Line> lines = new ArrayList<>();
        lines.add(new Line("SESSION PROFIT", GOLD));
        lines.add(new Line(sign + Stats.fmt(v), color));
        lines.add(new Line("Zeit: " + Stats.sessionTime(), GRAY));
        return lines;
    }

    /** {Breite, Hoehe} der Box fuer diese Zeilen. */
    public static int[] size(Font font, List<Line> lines) {
        int w = 0;
        for (Line l : lines) w = Math.max(w, font.width(l.text()));
        int h = (lines.size() - 1) * LH + 9;
        return new int[]{w + 2 * PAD, h + 2 * PAD};
    }

    public static void drawPanel(GuiGraphicsExtractor g, Font font, List<Line> lines, int x, int y) {
        int[] s = size(font, lines);
        Panel.draw(g, x, y, s[0], s[1]);
        int ty = y + PAD;
        for (Line l : lines) {
            g.text(font, l.text(), x + PAD, ty, l.color(), false);
            ty += LH;
        }
    }

    private static Line profitLine(String label, double v) {
        String sign = v > 0 ? "+" : "";
        int color = v > 0 ? GREEN : (v < 0 ? RED : WHITE);
        return new Line(label + sign + Stats.fmt(v), color);
    }
}
