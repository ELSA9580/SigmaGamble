package com.example.meinmod;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Liest Geld-Nachrichten aus dem Chat und fuehrt Session- und Gesamtsummen. */
public final class Stats {
    public static final int PAID = 0, RECEIVED = 1, BOUGHT = 2, SOLD = 3, TAX = 4;
    private static final String[] KEYS = {"paid", "received", "bought", "sold", "tax"};

    public static volatile long sessionStart = System.currentTimeMillis();
    public static final double[] session = new double[5];
    public static final double[] total = new double[5];

    private static final String AMOUNT = "\\$\\s?([\\d.,]+\\s?[KMBTkmbt]?)";

    // Beispiel: "You paid lukawal $ 100M (+$ 2M tax)"
    private static final Pattern P_PAID = Pattern.compile("^You paid \\S+ " + AMOUNT);
    // Annahme: "<name> paid you $ 100M" (bitte mit echter Zeile pruefen)
    static final Pattern P_RECEIVED = Pattern.compile("^(\\S+) paid you " + AMOUNT);
    // Beispiel: "You bought 64 Spruce Stairs for $ 57.8K"
    private static final Pattern P_BOUGHT = Pattern.compile("^You bought .+ for " + AMOUNT);
    // Annahme: "You sold ... for $ 1M" (bitte mit echter Zeile pruefen)
    private static final Pattern P_SOLD = Pattern.compile("^You sold .+ for " + AMOUNT);
    // Jede Zeile mit "(+$ 2M tax)" zaehlt als bezahlte Tax (pay, order, ah ...)
    private static final Pattern P_TAX = Pattern.compile("\\(\\+\\s?\\$\\s?([\\d.,]+\\s?[KMBTkmbt]?)\\s+tax\\)");

    private Stats() {}

    public static synchronized void onChat(String raw) {
        if (raw == null) return;
        String text = raw.trim();
        boolean changed = false;

        Matcher m;
        if ((m = P_PAID.matcher(text)).find()) {
            add(PAID, parse(m.group(1)));
            changed = true;
        } else if ((m = P_RECEIVED.matcher(text)).find()) {
            add(RECEIVED, parse(m.group(2)));
            changed = true;
        } else if ((m = P_BOUGHT.matcher(text)).find()) {
            add(BOUGHT, parse(m.group(1)));
            changed = true;
        } else if ((m = P_SOLD.matcher(text)).find()) {
            add(SOLD, parse(m.group(1)));
            changed = true;
        }

        Matcher t = P_TAX.matcher(text);
        if (t.find()) {
            add(TAX, parse(t.group(1)));
            changed = true;
        }

        if (changed) save();
    }

    public static synchronized void resetSession() {
        java.util.Arrays.fill(session, 0);
        sessionStart = System.currentTimeMillis();
    }

    public static synchronized void resetTotal() {
        java.util.Arrays.fill(total, 0);
        save();
    }

    private static void add(int i, double v) {
        session[i] += v;
        total[i] += v;
    }

    /** Profit = erhalten + verkauft - bezahlt - gekauft - Taxes. */
    public static double profit(double[] a) {
        return a[RECEIVED] + a[SOLD] - a[PAID] - a[BOUGHT] - a[TAX];
    }

    /** "57.8K", "2M", "1,302,510,540" -> Zahl */
    static double parse(String s) {
        String v = s.replace(",", "").replace(" ", "").trim();
        double mult = 1;
        if (!v.isEmpty()) {
            char c = Character.toUpperCase(v.charAt(v.length() - 1));
            if (Character.isLetter(c)) {
                switch (c) {
                    case 'K' -> mult = 1e3;
                    case 'M' -> mult = 1e6;
                    case 'B' -> mult = 1e9;
                    case 'T' -> mult = 1e12;
                    default -> { }
                }
                v = v.substring(0, v.length() - 1);
            }
        }
        try {
            return Double.parseDouble(v) * mult;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Dauer seit Session-Start, z.B. "26m 40s" */
    public static String sessionTime() {
        long sec = Math.max(0, (System.currentTimeMillis() - sessionStart) / 1000);
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return h + "h " + m + "m";
        return m + "m " + s + "s";
    }

    /** 1234567 -> "1.23M" */
    public static String fmt(double v) {
        double a = Math.abs(v);
        String sign = v < 0 ? "-" : "";
        if (a >= 1e12) return sign + String.format(Locale.ROOT, "%.2fT", a / 1e12);
        if (a >= 1e9) return sign + String.format(Locale.ROOT, "%.2fB", a / 1e9);
        if (a >= 1e6) return sign + String.format(Locale.ROOT, "%.2fM", a / 1e6);
        if (a >= 1e3) return sign + String.format(Locale.ROOT, "%.2fK", a / 1e3);
        return sign + String.format(Locale.ROOT, "%.0f", a);
    }

    private static Path file() {
        return Config.dir().resolve("meinmod-stats.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
            for (int i = 0; i < KEYS.length; i++) {
                String v = p.getProperty("total_" + KEYS[i]);
                if (v != null) total[i] = Double.parseDouble(v.trim());
            }
        } catch (IOException | RuntimeException e) {
            MeinModClient.LOGGER.warn("Statistik konnte nicht gelesen werden", e);
        }
    }

    private static void save() {
        Properties p = new Properties();
        for (int i = 0; i < KEYS.length; i++) {
            p.setProperty("total_" + KEYS[i], String.valueOf(total[i]));
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Gesamtsummen - Datei loeschen setzt sie zurueck");
        } catch (IOException e) {
            MeinModClient.LOGGER.warn("Statistik konnte nicht gespeichert werden", e);
        }
    }
}
