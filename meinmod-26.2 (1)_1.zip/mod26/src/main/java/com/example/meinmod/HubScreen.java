package com.example.meinmod;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** Haupt-Hub: Module an- und ausschalten. */
public class HubScreen extends Screen {
    private final Screen parent;

    public HubScreen(Screen parent) {
        super(Component.literal("Mein Hub"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 150;
        int xl = this.width / 2 - w - 5;
        int xr = this.width / 2 + 5;
        int y = this.height / 2 - 62;

        toggle(xl, y, w, "Profit-Tracker", () -> Config.profit, v -> Config.profit = v);
        toggle(xl, y + 24, w, "Taxes-Anzeige", () -> Config.taxes, v -> Config.taxes = v);
        toggle(xl, y + 48, w, "Session-Popup", () -> Config.popup, v -> Config.popup = v);
        toggle(xl, y + 72, w, "Pay-Buttons", () -> Config.buttons, v -> Config.buttons = v);

        this.addRenderableWidget(Button.builder(Component.literal("Edit HUD Layout"),
                b -> this.minecraft.gui.setScreen(new LayoutScreen(this))).bounds(xr, y, w, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Session zurücksetzen"),
                b -> Stats.resetSession()).bounds(xr, y + 48, w, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Gesamt zurücksetzen"),
                b -> Stats.resetTotal()).bounds(xr, y + 72, w, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Schließen"),
                b -> this.onClose()).bounds(this.width / 2 - 75, y + 108, w, 20).build());
    }

    private void toggle(int x, int y, int w, String name, Supplier<Boolean> get, Consumer<Boolean> set) {
        Button button = Button.builder(label(name, get.get()), b -> {
            set.accept(!get.get());
            Config.save();
            b.setMessage(label(name, get.get()));
        }).bounds(x, y, w, 20).build();
        this.addRenderableWidget(button);
    }

    private static Component label(String name, boolean on) {
        return Component.literal(name + ": ").append(
                Component.literal(on ? "AN" : "AUS").withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        String title = "Mein Hub";
        graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2,
                this.height / 2 - 84, 0xFFFFD21E, true);
    }

    @Override
    public void onClose() {
        this.minecraft.gui.setScreen(this.parent);
    }
}
