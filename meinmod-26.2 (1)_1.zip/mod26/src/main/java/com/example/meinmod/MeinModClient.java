package com.example.meinmod;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MeinModClient implements ClientModInitializer {
    public static final String ID = "meinmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    @Override
    public void onInitializeClient() {
        Config.load();
        Stats.load();

        // Liest nur eingehende Chat-/Systemnachrichten mit, sendet nichts.
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            Stats.onChat(message.getString());
        });

        // Haengt Buttons an eingehende /pay-Nachrichten
        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) ->
                overlay ? message : PayButtons.modify(message));

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(ID, "hud"),
                Hud::render);

        // Hub oeffnen: Standardtaste Rechts-Shift (aenderbar unter Steuerung)
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(ID, "main"));
        KeyMapping openHub = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.meinmod.open_hub",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_RSHIFT,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openHub.consumeClick()) {
                if (client.player != null) {
                    client.gui.setScreen(new HubScreen(null));
                }
            }
        });

        LOGGER.info("Tax & Profit Tracker geladen");
    }
}
