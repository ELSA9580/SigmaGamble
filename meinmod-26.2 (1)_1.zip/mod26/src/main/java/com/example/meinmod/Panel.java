package com.example.meinmod;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Schwarzes, durchscheinendes Viereck mit duennem gelbem Rand und abgerundeten Ecken. */
public final class Panel {
    public static final int BG = 0xA0000000;       // schwarz, translucent
    public static final int OUTLINE = 0xC8FFD21E;  // gelb, leicht translucent
    private static final int R = 4;                 // Eckenradius in Pixeln

    private Panel() {}

    /** Wie weit die Zeile k (0 = oberste) wegen der Rundung eingerueckt ist. */
    private static int inset(int k) {
        if (k >= R) return 0;
        double d = R - k - 0.5;
        return R - (int) Math.round(Math.sqrt(R * R - d * d));
    }

    public static void draw(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        draw(g, x, y, w, h, OUTLINE);
    }

    public static void draw(GuiGraphicsExtractor g, int x, int y, int w, int h, int outline) {
        if (w < 2 * R + 2 || h < 2 * R + 2) return;

        // Fuellung
        for (int k = 0; k < R; k++) {
            int in = inset(k);
            g.fill(x + in, y + k, x + w - in, y + k + 1, BG);
            g.fill(x + in, y + h - 1 - k, x + w - in, y + h - k, BG);
        }
        g.fill(x, y + R, x + w, y + h - R, BG);

        // Rand (1 Pixel)
        int in0 = inset(0);
        g.fill(x + in0, y, x + w - in0, y + 1, outline);
        g.fill(x + in0, y + h - 1, x + w - in0, y + h, outline);
        for (int k = 1; k < R; k++) {
            int l = inset(k);
            int end = Math.max(l + 1, inset(k - 1));
            // oben links / rechts
            g.fill(x + l, y + k, x + end, y + k + 1, outline);
            g.fill(x + w - end, y + k, x + w - l, y + k + 1, outline);
            // unten links / rechts
            g.fill(x + l, y + h - 1 - k, x + end, y + h - k, outline);
            g.fill(x + w - end, y + h - 1 - k, x + w - l, y + h - k, outline);
        }
        g.fill(x, y + R, x + 1, y + h - R, outline);
        g.fill(x + w - 1, y + R, x + w, y + h - R, outline);
    }
}
