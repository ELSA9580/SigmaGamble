package com.example.meinmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Einstellungen in config/meinmod.properties. */
public final class Config {
    public static boolean profit = true;   // Modul: Profit-Tracker
    public static boolean taxes = true;    // Modul: bezahlte Taxes
    public static boolean buttons = true;  // Modul: Buttons bei eingehenden /pay
    public static boolean popup = true;    // Modul: Session-Profit-Popup
    public static int x = 4;               // Position Haupt-Box
    public static int y = 4;
    public static int popupX = 4;          // Position Session-Popup
    public static int popupY = 80;

    private Config() {}

    static Path dir() {
        return FabricLoader.getInstance().getConfigDir();
    }

    public static void load() {
        Path f = dir().resolve("meinmod.properties");
        if (Files.exists(f)) {
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) {
                p.load(in);
                profit = bool(p, "profit", profit);
                taxes = bool(p, "taxes", taxes);
                buttons = bool(p, "buttons", buttons);
                popup = bool(p, "popup", popup);
                x = num(p, "x", x);
                y = num(p, "y", y);
                popupX = num(p, "popupX", popupX);
                popupY = num(p, "popupY", popupY);
            } catch (IOException | RuntimeException e) {
                MeinModClient.LOGGER.warn("Konfig konnte nicht gelesen werden", e);
            }
        }
        save();
    }

    public static void save() {
        Path f = dir().resolve("meinmod.properties");
        Properties p = new Properties();
        p.setProperty("profit", String.valueOf(profit));
        p.setProperty("taxes", String.valueOf(taxes));
        p.setProperty("buttons", String.valueOf(buttons));
        p.setProperty("popup", String.valueOf(popup));
        p.setProperty("x", String.valueOf(x));
        p.setProperty("y", String.valueOf(y));
        p.setProperty("popupX", String.valueOf(popupX));
        p.setProperty("popupY", String.valueOf(popupY));
        try (OutputStream out = Files.newOutputStream(f)) {
            p.store(out, "Module mit true/false an- oder ausschalten, x/y und popupX/popupY = Position (Pixel, besser im Hub unter HUD-Layout einstellen)");
        } catch (IOException e) {
            MeinModClient.LOGGER.warn("Konfig konnte nicht gespeichert werden", e);
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        String v = p.getProperty(k);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static int num(Properties p, String k, int def) {
        String v = p.getProperty(k);
        if (v == null) return def;
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
