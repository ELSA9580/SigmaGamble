package com.example.meinmod;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

/** HUD-Layout bearbeiten: Boxen mit der Maus an die gewuenschte Stelle ziehen. */
public class LayoutScreen extends Screen {
    private static final int NONE = 0, MAIN = 1, POPUP = 2;

    private final Screen parent;
    private int mx, my;
    private int dragging = NONE;
    private int offX, offY;

    public LayoutScreen(Screen parent) {
        super(Component.literal("HUD-Layout"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int y = this.height - 28;
        this.addRenderableWidget(Button.builder(Component.literal("Zurücksetzen"), b -> {
            Config.x = 4;
            Config.y = 4;
            Config.popupX = 4;
            Config.popupY = 80;
            Config.save();
        }).bounds(this.width / 2 - 155, y, 150, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Fertig"),
                b -> this.onClose()).bounds(this.width / 2 + 5, y, 150, 20).build());
    }

    private List<Hud.Line> mainLines() {
        List<Hud.Line> lines = Hud.mainLines();
        if (lines.isEmpty()) {
            lines = List.of(new Hud.Line("Haupt-Box (Module aus)", Hud.GRAY));
        }
        return lines;
    }

    private boolean inside(int x, int y, int[] size) {
        return mx >= x && mx < x + size[0] && my >= y && my < y + size[1];
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        this.mx = mouseX;
        this.my = mouseY;
        Font font = this.font;
        List<Hud.Line> main = mainLines();
        List<Hud.Line> popup = Hud.popupLines();
        int[] ms = Hud.size(font, main);
        int[] ps = Hud.size(font, popup);

        if (dragging == MAIN) {
            Config.x = Math.max(0, Math.min(this.width - ms[0], mx - offX));
            Config.y = Math.max(0, Math.min(this.height - ms[1], my - offY));
        } else if (dragging == POPUP) {
            Config.popupX = Math.max(0, Math.min(this.width - ps[0], mx - offX));
            Config.popupY = Math.max(0, Math.min(this.height - ps[1], my - offY));
        }

        super.extractRenderState(graphics, mouseX, mouseY, delta);

        Hud.drawPanel(graphics, font, main, Config.x, Config.y);
        Hud.drawPanel(graphics, font, popup, Config.popupX, Config.popupY);

        String hint = "Boxen mit der Maus ziehen";
        graphics.text(font, hint, this.width / 2 - font.width(hint) / 2, this.height - 46, Hud.GOLD, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        Font font = this.font;
        int[] ps = Hud.size(font, Hud.popupLines());
        int[] ms = Hud.size(font, mainLines());
        if (inside(Config.popupX, Config.popupY, ps)) {
            dragging = POPUP;
            offX = mx - Config.popupX;
            offY = my - Config.popupY;
            return true;
        }
        if (inside(Config.x, Config.y, ms)) {
            dragging = MAIN;
            offX = mx - Config.x;
            offY = my - Config.y;
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != NONE) return true;
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != NONE) {
            dragging = NONE;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        Config.save();
        this.minecraft.gui.setScreen(this.parent);
    }
}
