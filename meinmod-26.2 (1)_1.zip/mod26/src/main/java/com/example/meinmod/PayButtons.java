package com.example.meinmod;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;

import java.util.regex.Matcher;

/**
 * Haengt an eingehende "<Name> paid you $ <Betrag>"-Nachrichten klickbare Buttons.
 * Ein Klick schreibt den Befehl nur ins Chatfeld (du musst selbst Enter druecken).
 */
public final class PayButtons {
    private PayButtons() {}

    public static Component modify(Component message) {
        if (!Config.buttons) return message;

        Matcher m = Stats.P_RECEIVED.matcher(message.getString().trim());
        if (!m.find()) return message;

        String name = m.group(1);
        double amount = Stats.parse(m.group(2));
        if (amount <= 0) return message;

        MutableComponent out = message.copy();
        out.append(button("[2x]", "/pay " + name + " " + num(amount * 2), ChatFormatting.GREEN));
        out.append(button("[3x]", "/pay " + name + " " + num(amount * 3), ChatFormatting.GREEN));
        out.append(button("[payback]", "/pay " + name + " " + num(amount), ChatFormatting.GOLD));
        out.append(button("[bal]", "/bal " + name, ChatFormatting.AQUA));
        return out;
    }

    private static Component button(String label, String command, ChatFormatting color) {
        return Component.literal(" " + label).withStyle(style -> style
                .withColor(color)
                .withClickEvent(new ClickEvent.SuggestCommand(command))
                .withHoverEvent(new HoverEvent.ShowText(Component.literal(command))));
    }

    private static String num(double v) {
        return String.format("%.0f", v);
    }
}
