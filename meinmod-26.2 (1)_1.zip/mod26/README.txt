Tax & Profit Tracker (Fabric, Minecraft 26.2, Java 25)

Module:
  profit - Profit fuer Session und Gesamt (erhalten + verkauft - bezahlt - gekauft - Taxes)
  taxes  - nur die bezahlten Taxes (Session und Gesamt)

Die Mod liest nur eingehende Chatnachrichten mit und sendet nichts.
Jede Zeile mit "(+$ ... tax)" zaehlt als bezahlte Tax (z.B. bei /pay).

Dateien in config/:
  meinmod.properties        Module an/aus (true/false), x/y = Position
  meinmod-stats.properties  Gesamtsummen (Datei loeschen = zuruecksetzen)

Modul buttons (an/aus in meinmod.properties):
  Bei "<Name> paid you $ <Betrag>" erscheinen [2x] [3x] [payback] [bal].
  Ein Klick schreibt den Befehl (z.B. /pay Name 200000000) ins Chatfeld,
  abgeschickt wird erst, wenn du selbst Enter drueckst.

Hub:
  Im Spiel Rechts-Shift druecken (Taste aenderbar unter Optionen > Steuerung).
  Dort lassen sich Profit-Tracker, Taxes-Anzeige und Pay-Buttons einzeln an-/ausschalten,
  die Einstellung wird sofort gespeichert. Ausserdem: Session / Gesamt zuruecksetzen.

Design: alle Boxen schwarz translucent mit duennem gelbem Rand und abgerundeten Ecken.
Session-Popup: Session-Profit gross + Zeit, im Hub an/aus.
Hub > "Edit HUD Layout": Haupt-Box und Session-Popup mit der Maus verschieben.
